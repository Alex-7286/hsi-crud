package com.mz.prac1;

public class mapper {
}
