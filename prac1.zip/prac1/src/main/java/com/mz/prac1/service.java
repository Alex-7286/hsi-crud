package com.mz.prac1;

public class service {
}
