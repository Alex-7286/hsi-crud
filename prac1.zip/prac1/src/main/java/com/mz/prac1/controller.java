package com.mz.prac1;

package dev.kay.loadgen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/load")
class LoadController {

    record LoadRequest(
            String url,
            String method,
            Integer concurrency,   // 동시성 (기본 10)
            Integer qps,           // 목표 RPS (기본 100)
            Integer durationSec,   // 테스트 시간(초, 기본 30)
            Map<String,String> headers,
            String body
    ) {}

    record LoadResult(
            String url, String method,
            int concurrency, int qps, int durationSec,
            long total, long ok, long fail, double actualRps,
            long minMs, double avgMs, long maxMs, long p50, long p90, long p99
    ) {}

    @PostMapping
    public LoadResult run(@RequestBody LoadRequest in) throws Exception {
        String url = Objects.requireNonNull(in.url(), "url required");
        String method = Optional.ofNullable(in.method()).orElse("GET").toUpperCase(Locale.ROOT);
        int conc = Optional.ofNullable(in.concurrency()).orElse(10);
        int qps  = Optional.ofNullable(in.qps()).orElse(100);
        int duration = Optional.ofNullable(in.durationSec()).orElse(30);
        Map<String,String> headers = Optional.ofNullable(in.headers()).orElseGet(HashMap::new);
        String body = Optional.ofNullable(in.body()).orElse("");

        HttpClient client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)           // keep-alive
                .connectTimeout(Duration.ofSeconds(5))
                .build();

        ExecutorService workers = Executors.newFixedThreadPool(conc);
        AtomicLong total = new AtomicLong(0);
        LongAdder ok = new LongAdder();
        LongAdder fail = new LongAdder();
        List<Long> latencies = Collections.synchronizedList(new ArrayList<>());

        long start = System.nanoTime();
        long end   = start + TimeUnit.SECONDS.toNanos(duration);
        long interval = Math.max(1, (long)Math.floor(1_000_000_000.0 / qps)); // 나노초 간격

        // 발사 스레드(정확한 간격으로 submit)
        Thread driver = new Thread(() -> {
            long next = System.nanoTime();
            while (true) {
                long now = System.nanoTime();
                if (now >= end) break;
                if (now < next) {
                    LockSupport.parkNanos(next - now);
                    continue;
                }
                next += interval;
                workers.submit(() -> {
                    try {
                        HttpRequest.Builder b = HttpRequest.newBuilder()
                                .uri(URI.create(url))
                                .timeout(Duration.ofSeconds(10));
                        headers.forEach(b::header);

                        if (method.equals("POST") || method.equals("PUT") || method.equals("PATCH")) {
                            if (!headers.keySet().stream().map(String::toLowerCase).collect(Collectors.toSet()).contains("content-type")) {
                                b.header("Content-Type", "application/json");
                            }
                            b.method(method, HttpRequest.BodyPublishers.ofString(body));
                        } else {
                            b.method(method, HttpRequest.BodyPublishers.noBody());
                        }

                        HttpRequest req = b.build();
                        long t0 = System.nanoTime();
                        HttpResponse<Void> resp = client.send(req, HttpResponse.BodyHandlers.discarding());
                        long t1 = System.nanoTime();

                        total.incrementAndGet();
                        latencies.add(TimeUnit.NANOSECONDS.toMillis(t1 - t0));
                        if (resp.statusCode() >= 200 && resp.statusCode() < 400) ok.increment();
                        else fail.increment();
                    } catch (Exception e) {
                        total.incrementAndGet();
                        fail.increment();
                    }
                });
            }
        });
        driver.start();
        driver.join();         // 드라이버 종료
        workers.shutdown();
        workers.awaitTermination(duration + 10L, TimeUnit.SECONDS);

        long elapsedNs = System.nanoTime() - start;
        double actualRps = total.get() * 1_000_000_000.0 / elapsedNs;

        // 통계
        long min = 0, max = 0; double avg = 0;
        long p50=0, p90=0, p99=0;
        if (!latencies.isEmpty()) {
            List<Long> sorted = new ArrayList<>(latencies);
            Collections.sort(sorted);
            min = sorted.get(0);
            max = sorted.get(sorted.size()-1);
            avg = sorted.stream().mapToLong(Long::longValue).average().orElse(0);
            p50 = percentile(sorted, 50);
            p90 = percentile(sorted, 90);
            p99 = percentile(sorted, 99);
        }

        return new LoadResult(url, method, conc, qps, duration,
                total.get(), ok.sum(), fail.sum(), actualRps,
                min, avg, max, p50, p90, p99);
    }

    private static long percentile(List<Long> sorted, int p) {
        if (sorted.isEmpty()) return 0;
        int n = sorted.size();
        int idx = (int)Math.ceil((p / 100.0) * n) - 1;
        if (idx < 0) idx = 0;
        if (idx >= n) idx = n - 1;
        return sorted.get(idx);
    }
}

