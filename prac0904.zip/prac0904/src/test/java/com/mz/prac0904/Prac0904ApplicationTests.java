package com.mz.prac0904;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prac0904ApplicationTests {

	@Test
	void contextLoads() {
	}

}
