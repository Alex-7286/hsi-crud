package com.mz.prac0904;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class LoadController {

    private final LoadManager manager;

    public LoadController(LoadManager manager) { this.manager = manager; }

    @GetMapping("/")
    public String index(@RequestParam(required = false) String id, Model model) {
        if (id != null) {
            RunningTestSnapshot snap = manager.snapshot(id);
            model.addAttribute("snap", snap);
            model.addAttribute("id", id);
            model.addAttribute("autoRefresh", true);
        }
        return "index";
    }

    @PostMapping("/start")
    public String start(
            @RequestParam String url,
            @RequestParam(defaultValue = "10") int threads,
            @RequestParam(defaultValue = "5000") int timeoutMs,
            @RequestParam(defaultValue = "60") int durationSec, // 0이면 무한
            @RequestParam(defaultValue = "4096") int chunkBytes,
            @RequestParam(defaultValue = "application/octet-stream") String contentType,
            @RequestParam(required = false) MultipartFile audio,  // 선택: 업로드 오디오
            Model model
    ) throws Exception {
        byte[] audioBytes = (audio != null && !audio.isEmpty()) ? audio.getBytes() : null;
        String id = manager.start(url, threads, timeoutMs, durationSec, chunkBytes, contentType, audioBytes);
        return "redirect:/?id=" + id;
    }

    @PostMapping("/stop")
    public String stop(@RequestParam String id) {
        manager.stop(id);
        return "redirect:/?id=" + id;
    }
}
