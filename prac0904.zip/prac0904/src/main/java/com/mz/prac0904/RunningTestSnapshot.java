package com.mz.prac0904;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.LongAdder;

public class RunningTestSnapshot {
    public final String id;
    public final String url;
    public final Instant startAt;
    public final Instant endAt; // null이면 진행 중
    public final int threads;
    public final int timeoutMs;
    public final int durationSec;
    public final long sent;
    public final long success;
    public final long failure;
    public final long avgLatencyMs;
    public final long maxLatencyMs;
    public final double tps;
    public final ConcurrentMap<Integer, LongAdder> statusDist;

    public RunningTestSnapshot(String id, String url, Instant startAt, Instant endAt,
                               int threads, int timeoutMs, int durationSec,
                               long sent, long success, long failure,
                               long avgLatencyMs, long maxLatencyMs, double tps,
                               ConcurrentMap<Integer, LongAdder> statusDist) {
        this.id = id; this.url = url; this.startAt = startAt; this.endAt = endAt;
        this.threads = threads; this.timeoutMs = timeoutMs; this.durationSec = durationSec;
        this.sent = sent; this.success = success; this.failure = failure;
        this.avgLatencyMs = avgLatencyMs; this.maxLatencyMs = maxLatencyMs; this.tps = tps;
        this.statusDist = statusDist;
    }

    public static RunningTestSnapshot finished(String id, RunningTestSnapshot s) {
        return s; // 단순화 — 존재하지 않으면 null을 JSP에서 처리
    }
}

