package com.mz.prac0904;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.LongAdder;

class RunningTest {
    private final String id;
    private final String url;
    private final int threads;
    private final int timeoutMs;
    private final int durationSec;        // 0 = 무한
    private final int chunkBytes;
    private final String contentType;
    private final byte[] audioBytes;      // null이면 더미 페이로드 사용
    private final ExecutorService pool;

    private final Instant startAt = Instant.now();
    private volatile Instant endAt = null;
    private final AtomicBoolean stop = new AtomicBoolean(false);

    // 통계
    private final LongAdder sent = new LongAdder();
    private final LongAdder success = new LongAdder();
    private final LongAdder failure = new LongAdder();
    private final LongAdder sumLatencyMs = new LongAdder();
    private final LongAdder maxLatencyMs = new LongAdder();
    private final ConcurrentMap<Integer, LongAdder> statusDist = new ConcurrentHashMap<>();

    RunningTest(String id, String url, int threads, int timeoutMs, int durationSec,
                int chunkBytes, String contentType, byte[] audioBytes) {
        this.id = id; this.url = url; this.threads = threads; this.timeoutMs = timeoutMs;
        this.durationSec = durationSec; this.chunkBytes = chunkBytes;
        this.contentType = contentType;
        this.audioBytes = (audioBytes != null && audioBytes.length > 0) ? audioBytes : genDummyAudio();
        this.pool = Executors.newFixedThreadPool(threads);
    }

    void start(Runnable onFinish) {
        for (int i=0; i<threads; i++) {
            pool.submit(this::workerLoop);
        }
        // 종료 감시 스레드
        Executors.newSingleThreadExecutor().submit(() -> {
            try {
                if (durationSec > 0) {
                    Thread.sleep(durationSec * 1000L);
                    if (!stop.get()) stop.set(true);
                }
                pool.shutdown();
                pool.awaitTermination(7, TimeUnit.DAYS);
            } catch (InterruptedException ignored) {} finally {
                endAt = Instant.now();
                onFinish.run();
            }
        });
    }

    void stop() { stop.set(true); pool.shutdownNow(); }

    RunningTestSnapshot snapshot() {
        long sentV = sent.sum();
        long succV = success.sum();
        long failV = failure.sum();
        long sumLat = sumLatencyMs.sum();
        long maxLat = maxLatencyMs.sum();
        long avg = sentV > 0 ? Math.round((double) sumLat / sentV) : 0;
        long elapsedMs = Duration.between(startAt, Optional.ofNullable(endAt).orElse(Instant.now())).toMillis();
        double tps = elapsedMs > 0 ? (sentV * 1000.0 / elapsedMs) : 0.0;
        return new RunningTestSnapshot(id, url, startAt, endAt, threads, timeoutMs, durationSec,
                sentV, succV, failV, avg, maxLat, tps, statusDist);
    }

    // ------- Worker -------
    private void workerLoop() {
        while (!stop.get()) {
            long started = System.nanoTime();
            int code = -1;
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(timeoutMs);
                conn.setReadTimeout(timeoutMs);
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", contentType);
                // 청크 전송: 마지막에 0바이트 청크는 HttpURLConnection이 자동으로 전송
                conn.setChunkedStreamingMode(chunkBytes);

                try (OutputStream os = conn.getOutputStream()) {
                    streamInChunks(os, audioBytes, chunkBytes);
                    // os.close() 시점에 0바이트 청크가 나가며 요청 종료
                }

                code = conn.getResponseCode();

                // finalize 신호 예시 처리: 헤더/응답에 'finalize' 문자열이 포함되면 완료로 간주
                // (서비스 규약에 맞게 변경하세요)
                String hdr = conn.getHeaderField("X-Finalize");
                if (hdr == null && code == 200) {
                    // 본문 살짝만 읽어 finalize 여부 체크(성능 위해 1KB 제한)
                    var is = conn.getInputStream();
                    byte[] buf = is.readNBytes(1024);
                    String body = new String(buf, StandardCharsets.UTF_8);
                    // 필요 시 조건 수정
                    boolean finalized = body.toLowerCase().contains("finalize");
                    // finalized를 통계에 별도 사용하려면 확장
                }

                markLatency(success, code, started);
            } catch (Exception e) {
                markLatency(failure, code, started);
            }
            // 다음 음원 전송 (무한/시간 내 루프)
        }
    }

    private void markLatency(LongAdder bucket, int code, long startedNs) {
        long tookMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startedNs);
        sent.increment(); bucket.increment();
        sumLatencyMs.add(tookMs);
        // max
        long prev;
        do { prev = maxLatencyMs.sum(); } while (tookMs > prev && !CASMax(prev, tookMs));
        // status 분포
        if (code >= 0) statusDist.computeIfAbsent(code, k -> new LongAdder()).increment();
    }
    private boolean CASMax(long prev, long next) {
        synchronized (maxLatencyMs) { // LongAdder에 CAS가 없어 간단 동기화
            long now = maxLatencyMs.sum();
            if (now == prev && next > now) {
                // 편법: 차액만큼 더해 최대치 갱신
                long delta = next - now;
                maxLatencyMs.add(delta);
                return true;
            }
            return false;
        }
    }

    private void streamInChunks(OutputStream os, byte[] bytes, int chunk) throws Exception {
        int off = 0;
        while (off < bytes.length) {
            int len = Math.min(chunk, bytes.length - off);
            os.write(bytes, off, len);
            off += len;
        }
        os.flush(); // close 시 0바이트 청크 전송
    }

    private byte[] genDummyAudio() {
        // 5초 길이의 더미(무음) 바이트(약 80KB) — 실제 서비스 규약에 맞추어 교체 가능
        byte[] b = new byte[80 * 1024];
        return b;
    }
}

