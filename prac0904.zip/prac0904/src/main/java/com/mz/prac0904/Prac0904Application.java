package com.mz.prac0904;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prac0904Application {

	public static void main(String[] args) {
		SpringApplication.run(Prac0904Application.class, args);
	}

}
