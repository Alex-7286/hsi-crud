package com.mz.prac0904;


import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.*;

@Service
public class LoadManager {
    private final Map<String, RunningTest> running = new ConcurrentHashMap<>();

    public String start(String url, int threads, int timeoutMs, int durationSec,
                        int chunkBytes, String contentType, byte[] audioBytes) {
        String id = UUID.randomUUID().toString().substring(0, 8);
        RunningTest rt = new RunningTest(id, url, threads, timeoutMs, durationSec, chunkBytes, contentType, audioBytes);
        running.put(id, rt);
        rt.start(() -> running.remove(id)); // 끝나면 자동 제거
        return id;
    }

    public void stop(String id) {
        RunningTest rt = running.get(id);
        if (rt != null) rt.stop();
    }

    public RunningTestSnapshot snapshot(String id) {
        RunningTest rt = running.get(id);
        if (rt == null) return RunningTestSnapshot.finished(id, null);
        return rt.snapshot();
    }
}

