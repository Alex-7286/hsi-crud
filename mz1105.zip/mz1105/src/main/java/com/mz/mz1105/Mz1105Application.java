package com.mz.mz1105;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mz1105Application {

	public static void main(String[] args) {
		SpringApplication.run(Mz1105Application.class, args);
	}

}
