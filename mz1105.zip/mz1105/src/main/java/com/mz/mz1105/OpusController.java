package com.mz.mz1105;

import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.*;

@Controller
public class OpusController {

    // ✅ 절대경로 지정 (Windows)
    private static final String UPLOAD_DIR = "C:\\opus";

    @PostMapping("/upload")
    @ResponseBody
    public ResponseEntity<?> uploadAudio(@RequestParam("file") MultipartFile file) throws IOException {
        File dir = new File(UPLOAD_DIR);
        if (!dir.exists()) dir.mkdirs();

        Path path = Paths.get(UPLOAD_DIR, file.getOriginalFilename());
        file.transferTo(path.toFile());

        System.out.println("저장 위치: " + path.toAbsolutePath());
        return ResponseEntity.ok().body(new UploadResponse(file.getOriginalFilename()));
    }

    @GetMapping("/play/{fileName}")
    public ResponseEntity<byte[]> playAudio(@PathVariable String fileName) throws IOException {
        Path path = Paths.get(UPLOAD_DIR, fileName);
        if (!Files.exists(path)) {
            System.out.println("파일 없음: " + path.toAbsolutePath());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }


        byte[] audio = Files.readAllBytes(path);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("audio/ogg"));
        headers.setContentDisposition(ContentDisposition.inline().filename(fileName).build());

        return new ResponseEntity<>(audio, headers, HttpStatus.OK);
    }

    static class UploadResponse {
        public String fileName;
        public UploadResponse(String fileName) { this.fileName = fileName; }
    }
}
